import React from "react";

export type DataStats = {
	id: number;
	titleKey: string;
	value: string;
	percents: string;
	isIncrease: boolean;
	color: string;
	icon: React.ReactNode;
};

export type OverviewData = {
	id: number;
	title: string;
	titleKey: string;
	value: string;
	percents: string;
	isIncrease: boolean;
};

export const dataStats: DataStats[] = [
	{
		id: 1,
		titleKey: "total_visitors",
		value: "3.456K",
		isIncrease: true,
		percents: "0.43%",
		color: "#3FD97F",
		icon: (
			<svg
				width='26'
				height='26'
				viewBox='0 0 26 26'
				fill='none'
				xmlns='http://www.w3.org/2000/svg'
			>
				<path
					d='M10.5625 13C10.5625 11.6538 11.6538 10.5625 13 10.5625C14.3462 10.5625 15.4375 11.6538 15.4375 13C15.4375 14.3462 14.3462 15.4375 13 15.4375C11.6538 15.4375 10.5625 14.3462 10.5625 13Z'
					fill='white'
				/>
				<path
					fillRule='evenodd'
					clipRule='evenodd'
					d='M2.16666 13C2.16666 14.776 2.62703 15.3741 3.54779 16.5703C5.38628 18.9589 8.46961 21.6667 13 21.6667C17.5304 21.6667 20.6137 18.9589 22.4522 16.5703C23.3729 15.3741 23.8333 14.776 23.8333 13C23.8333 11.2241 23.3729 10.6259 22.4522 9.42973C20.6137 7.04123 17.5304 4.33337 13 4.33337C8.46961 4.33337 5.38628 7.04123 3.54779 9.42973C2.62703 10.6259 2.16666 11.2241 2.16666 13ZM13 8.93754C10.7563 8.93754 8.93749 10.7564 8.93749 13C8.93749 15.2437 10.7563 17.0625 13 17.0625C15.2436 17.0625 17.0625 15.2437 17.0625 13C17.0625 10.7564 15.2436 8.93754 13 8.93754Z'
					fill='white'
				/>
			</svg>
		),
	},
	{
		id: 2,
		titleKey: "total_revenue",
		value: "$42.2K",
		isIncrease: true,
		percents: "4.35%",
		color: "#FF9C55",
		icon: (
			<svg
				width='26'
				height='26'
				viewBox='0 0 26 26'
				fill='none'
				xmlns='http://www.w3.org/2000/svg'
			>
				<path
					fillRule='evenodd'
					clipRule='evenodd'
					d='M13 23.8333C18.9831 23.8333 23.8333 18.983 23.8333 13C23.8333 7.01687 18.9831 2.16663 13 2.16663C7.01691 2.16663 2.16666 7.01687 2.16666 13C2.16666 18.983 7.01691 23.8333 13 23.8333ZM13.8125 6.49996C13.8125 6.05123 13.4487 5.68746 13 5.68746C12.5513 5.68746 12.1875 6.05123 12.1875 6.49996V6.84309C10.4212 7.15935 8.9375 8.48637 8.9375 10.2916C8.9375 12.3685 10.9013 13.8125 13 13.8125C14.4912 13.8125 15.4375 14.7937 15.4375 15.7083C15.4375 16.6229 14.4912 17.6041 13 17.6041C11.5088 17.6041 10.5625 16.6229 10.5625 15.7083C10.5625 15.2596 10.1987 14.8958 9.75 14.8958C9.30127 14.8958 8.9375 15.2596 8.9375 15.7083C8.9375 17.5135 10.4212 18.8406 12.1875 19.1568V19.5C12.1875 19.9487 12.5513 20.3125 13 20.3125C13.4487 20.3125 13.8125 19.9487 13.8125 19.5V19.1568C15.5788 18.8406 17.0625 17.5135 17.0625 15.7083C17.0625 13.6314 15.0987 12.1875 13 12.1875C11.5088 12.1875 10.5625 11.2063 10.5625 10.2916C10.5625 9.377 11.5088 8.39579 13 8.39579C14.4912 8.39579 15.4375 9.377 15.4375 10.2916C15.4375 10.7404 15.8013 11.1041 16.25 11.1041C16.6987 11.1041 17.0625 10.7404 17.0625 10.2916C17.0625 8.48637 15.5788 7.15935 13.8125 6.84309V6.49996Z'
					fill='white'
				/>
			</svg>
		),
	},
	{
		id: 3,
		titleKey: "free_users",
		value: "43543",
		isIncrease: true,
		percents: "2.59%",
		color: "#8155FF",
		icon: (
			<svg
				width='26'
				height='26'
				viewBox='0 0 26 26'
				fill='none'
				xmlns='http://www.w3.org/2000/svg'
			>
				<ellipse
					cx='9.75106'
					cy='6.49996'
					rx='4.33333'
					ry='4.33333'
					fill='white'
				/>
				<ellipse
					cx='9.75106'
					cy='18.4177'
					rx='7.58333'
					ry='4.33333'
					fill='white'
				/>
				<path
					d='M22.7496 18.4171C22.7496 20.212 20.5444 21.6671 17.852 21.6671C18.6452 20.8 19.1907 19.7117 19.1907 18.4186C19.1907 17.124 18.644 16.0346 17.8493 15.1671C20.5417 15.1671 22.7496 16.6222 22.7496 18.4171Z'
					fill='white'
				/>
				<path
					d='M19.4996 6.50073C19.4996 8.29566 18.0445 9.75073 16.2496 9.75073C15.8582 9.75073 15.483 9.68155 15.1355 9.55474C15.648 8.6533 15.9407 7.6106 15.9407 6.49952C15.9407 5.38927 15.6484 4.34729 15.1366 3.44631C15.4838 3.31977 15.8586 3.25073 16.2496 3.25073C18.0445 3.25073 19.4996 4.70581 19.4996 6.50073Z'
					fill='white'
				/>
			</svg>
		),
	},
	{
		id: 4,
		titleKey: "pro_users",
		value: "5334",
		isIncrease: false,
		percents: "0.95%",
		color: "#18BFFF",
		icon: (
			<svg
				width='26'
				height='26'
				viewBox='0 0 26 26'
				fill='none'
				xmlns='http://www.w3.org/2000/svg'
			>
				<ellipse
					cx='9.75106'
					cy='6.49996'
					rx='4.33333'
					ry='4.33333'
					fill='white'
				/>
				<ellipse
					cx='9.75106'
					cy='18.4177'
					rx='7.58333'
					ry='4.33333'
					fill='white'
				/>
				<path
					d='M22.7496 18.4171C22.7496 20.212 20.5444 21.6671 17.852 21.6671C18.6452 20.8 19.1907 19.7117 19.1907 18.4186C19.1907 17.124 18.644 16.0346 17.8492 15.1671C20.5416 15.1671 22.7496 16.6222 22.7496 18.4171Z'
					fill='white'
				/>
				<path
					d='M19.4996 6.50073C19.4996 8.29566 18.0445 9.75073 16.2496 9.75073C15.8582 9.75073 15.4829 9.68155 15.1354 9.55474C15.6479 8.6533 15.9407 7.6106 15.9407 6.49952C15.9407 5.38927 15.6484 4.34729 15.1366 3.44631C15.4838 3.31977 15.8586 3.25073 16.2496 3.25073C18.0445 3.25073 19.4996 4.70581 19.4996 6.50073Z'
					fill='white'
				/>
			</svg>
		),
	},
];

export const overviewData: OverviewData[] = [
	{
		id: 1,
		title: "Monthly Recurring Revenue",
		titleKey: "monthly_recurring_revenue",
		value: "$9.1",
		percents: "(+4%)",
		isIncrease: true,
	},
	{
		id: 2,
		title: "Revenue",
		titleKey: "revenue",
		value: "$32.9",
		percents: "(+4%)",
		isIncrease: true,
	},
	{
		id: 3,
		title: "Fees",
		titleKey: "fees",
		value: "$50",
		percents: "(+4%)",
		isIncrease: true,
	},
	{
		id: 4,
		title: "New Customers",
		titleKey: "new_customers",
		value: "$231",
		percents: "(+4%)",
		isIncrease: true,
	},
	{
		id: 5,
		title: "Churn",
		titleKey: "churn",
		value: "$7.4",
		percents: "(+4%)",
		isIncrease: true,
	},
	{
		id: 6,
		title: "Support Ticket",
		titleKey: "support_ticket",
		value: "$8.9",
		percents: "(-3%)",
		isIncrease: false,
	},
];
