export function getScrollBarWidth() {
	return window.innerWidth - document.documentElement.clientWidth;
}
