import NotFound from "@/components/404";

export default function NotFoundPage() {
	return <NotFound />;
}
