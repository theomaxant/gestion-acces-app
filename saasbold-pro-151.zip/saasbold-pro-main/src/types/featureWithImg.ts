export type FeatureWithImg = {
	title: string;
	subtitle: string;
	features: string[];
};
