export type FeatureItem = {
	id: number;
	title: string;
	description: string;
	icon: string;
};
