export type Testimonial = {
	name: string;
	designation: string;
	image: string;
	comment: string;
};
