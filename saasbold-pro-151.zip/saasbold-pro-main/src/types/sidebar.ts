export type Sidebar = {
	id: number;
	titleKey: string;
	path?: string;
	icon: React.ReactNode;
	comingSoon?: boolean;
};
